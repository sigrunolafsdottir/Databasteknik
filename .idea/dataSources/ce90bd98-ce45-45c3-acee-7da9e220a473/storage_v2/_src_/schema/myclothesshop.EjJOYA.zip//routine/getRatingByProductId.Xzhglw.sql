create
    definer = root@localhost function getRatingByProductId(productId int) returns double
BEGIN


RETURN (SELECT avg(numericRating) FROM rating 
inner join rategrade on
rateGrade.Id = rating.rateGradeId
where rating.productId = productId);
END;

