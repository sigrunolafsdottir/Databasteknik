create
    definer = root@localhost procedure getAmbrosia2()
BEGIN
	select * from child where name like 'Ambrosia';
END;

