create
    definer = root@localhost procedure addRating(IN comment varchar(1000), IN productId int, IN ratinggradeId int)
BEGIN
	insert into rating (rateGradeId, productId, comment) values
			(ratinggradeId, productId, comment);
END;

