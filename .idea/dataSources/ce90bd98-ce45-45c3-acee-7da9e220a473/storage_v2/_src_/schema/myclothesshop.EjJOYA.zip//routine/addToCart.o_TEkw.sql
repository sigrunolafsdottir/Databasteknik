create
    definer = root@localhost procedure addToCart(IN customerId int, IN productVariantId int, IN orderId int)
BEGIN
	DECLARE nextOrderNr INT DEFAULT 0;
    DECLARE amountOfProductVariantInStore INT DEFAULT 0;
    
	SELECT COUNT(*) INTO nextOrderNr
	FROM myclothesshop.clothOrder;
    SET nextOrderNr = nextOrderNr + 1;
    
    SELECT productvariant.amountLeft INTO amountOfProductVariantInStore
	FROM myclothesshop.productvariant
    where id = productVariantId;
    
    if amountOfProductVariantInStore > 0 then
    
		if orderId is null then
		
			insert into clothorder (customerId) values
			(customerId);

			insert into orderItem (orderId, productVariantId) VALUES
			(nextOrderNr,productVariantId);
		else
			insert into orderItem (orderId, productVariantId) VALUES
			(orderId,productVariantId);
		end if;
		
        update productvariant 
        set amountleft = amountleft - 1 
        where productVariant.id = productVariantId;
    
    end if;
    
END;

