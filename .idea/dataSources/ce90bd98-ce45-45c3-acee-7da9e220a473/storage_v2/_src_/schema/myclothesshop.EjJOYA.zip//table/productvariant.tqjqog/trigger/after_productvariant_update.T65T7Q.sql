create definer = root@localhost trigger after_productvariant_update
    after UPDATE
    on productvariant
    for each row
BEGIN

	DECLARE amountOfProductVariantInStore INT DEFAULT -1;
    
    SET amountOfProductVariantInStore = NEW.amountLeft;
    
    if amountOfProductVariantInStore = 0 THEN
		INSERT INTO `outofproductvariant` (`productVariantId`) values (NEW.Id);
	end if;
	
END;

